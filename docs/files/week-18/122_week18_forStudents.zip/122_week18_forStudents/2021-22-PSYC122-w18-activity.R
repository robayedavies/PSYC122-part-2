


############################################################################################################


# In Week 18, we aim to further develop skills in visualizing *and* in analyzing psychological data

# We do this to learn how to answer research questions like:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# These kinds of research questions can often be answered through analyses using linear models
# -- We will use linear models to estimate the association between predictors and outcomes


# When we do these analyses, we will need to think about how we report the results:  
# -- we usually need to report information about the kind of model we specify;
# -- and we will need to report the nature of the association estimated in our model;
# -- we usually need to decide, is the association significant?
# -- does the association reflect a positive or negative relationship between outcome and predictor?
# -- is the association we see in our sample data relatively strong or weak?


# At every stage, as we work, we will visualize the data to:
# -- Understand the shape of the relationships we may observe or predict
# -- Evaluate our data so that we can consider the limits or biases in our sample

# As we work, we will develop skills in producing appealing plots for professional audiences 


# -- I work through the parts, tasks and questions with similar data in:
# 2021-22-PSYC122-w18-how-to.R
# -- If you are unsure how to do something, check that out and then come back here



############################################################################################################


# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# We will take things step-by-step

# -- I will be explicit about when I will ask you to:
# -- consolidate -- where you have had the chance to practice things before;
# -- revise -- where you have started to do things and maybe can use some practice to strengthen skills;
# -- encounter -- where you are doing things that are new;
# -- extend -- where you can do things that will stretch you -- where you might need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this activity workbook, we use data from a second 2020 study of the response of adults from a UK national
# sample to written health information

# study-two-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: should be no surprises here --


# -- Task 3 -- Read in the data file we will be using: 
# study-two-general-participants.csv
# -- hint: Task 3 -- Use the read_csv() function to read the data file into R
# -- hint: Task 3 -- When you read the data file in, give the data object you create a clear name 
# e.g. study.two.gen

# -- write your code here and run it --


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- Use the summary() or head() functions to take a look
# -- hint: Task 4 -- Even though you have done this before, you will want to do it again, here

# -- write your code here and run it --


# -- In this activity, we are going to focus on the potential association between health literacy 'HLVA'
# and mean accuracy of understanding 'mean.acc' of health information


# -- Q.1. -- What are the mean, minimum and maximum observed values for 'HLVA'?


# -- Q.2. -- What are the mean, minimum and maximum observed values for 'mean.acc'?


# -- Q.3. -- What do you think are the minimum possible values for 'HLVA' and 'mean.acc'?
# -- hint: Q.3 -- When we talk about minimum possible values, we have to consider what the test scores *could be*  
# if, say, someone got no responses in a test correct



############################################################################################################
## Part 3: Use histograms to examine the distributions of variables ########################################


# -- revision: practice to strengthen skills --


# -- Task 5 -- Draw histograms to examine the distributions of variables

# -- Revise editing:
# -- 1 -- the appearance of the bars using binwidth
# -- 2 -- the colour of the background using theme_bw()
# -- 3 -- the appearance of the labels using labs()
# -- 4 -- setting the x-axis limits to reflect the full range of possible scores on the x-axis variable
# -- hint: Task 5 -- You may need to refer to information about variables from the summary() results

# -- Here, we shall focus on two variables, mean accuracy of understanding ('mean.acc') and 
# health literacy 'HLVA'
# -- Draw histograms to represent the distributions of 'mean.acc' and 'HLVA' scores
# -- You will need to make your own judgment on binwidth

# -- write your code here and run it --


# -- Q.4. -- Look at the distribution of 'mean.acc' scores and answer the following questions:
# -- Q.4.1. -- What is the peak or modal 'mean.acc' scores

# -- Q.4.2. -- Are there any features of the distribution that may present an issue or problem for
# accurate correlation or linear model analyses?

# -- Q.5. -- Look at the distribution of 'HLVA' scores and answer the following questions:
# -- Q.5.1. -- What is the peak or modal 'HLVA' scores

# -- Q.5.2. -- Are there any features of the distribution that may present an issue or problem for
# accurate correlation or linear model analyses?



############################################################################################################
## Part 4: Now draw scatterplots to examine associations between variables #################################


# -- revision: make sure you are confident about doing these things --


# -- Task 6 -- Create a scatterplot to examine the association between some variables

# -- Revise making edits to:
# -- 1 -- the appearance of the points using alpha, size, shape, and colour
# -- 2 -- the colour of the background using theme_bw()
# -- 3 -- the appearance of the labels using labs()
# -- 4 -- Set the x-axis and y-axis limits to the minimum-maximum ranges of the variables we plot

# -- Here, we shall focus on two variables, mean accuracy of understanding ('mean.acc') and 
# health literacy 'HLVA'

# -- write your code here and run it --


# -- Q.6. -- Look at the scatterplot: what is the association (if any) between health literacy and
# mean accuracy? Describe the trend as it appears to you.


# -- Q.7. -- Does anything you have learnt in previous tasks, or in answering previous questions, mean
# that you are concerned about your or our capacity to detect an association, given these data?


# -- Now experiment!


# -- You can change the transparency (alpha), size, colour and shape of important parts of a plot
# -- Here, we are changing the appearance of the points
# -- But you can also change the transparency (alpha), size, colour and shape of reference lines
# added to a plot

# -- The ggplot geom_point() reference information is here: 
# https://ggplot2.tidyverse.org/reference/geom_point.html
# -- where you can see some examples of the choices you can make

# -- Some useful information about shape options is here:
# http://www.cookbook-r.com/Graphs/Shapes_and_line_types/
# -- Some useful information about shape options is here:
# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/


# -- Task 7 -- Make changes to:
# -- 1 -- the appearance of the points using alpha, size, shape, and colour
# -- 2 -- the colour of the background using different themes
# -- 3 -- the wording of the labels using labs()


# -- Q.8. -- Can you find ggplot reference information on changing themes or plot titles?
# -- A.8. -- Reference information can be found here:
# https://ggplot2.tidyverse.org/reference/ggtheme.html  
# https://ggplot2.tidyverse.org/reference/labs.html


# -- Task 8 -- Now make changes to:
# -- 4 -- the plot theme
# -- 5 -- and add a title for the plot, concisely describing what it shows

# -- write your code here and run it --


# -- hint: Task 8 -- You can get text written over two lines using a special symbol
# "There are too many words in this title" but if you write this:
# "There are too many \n words in this title" then R will print it like this:
# "There are too many
# words in this title"
# -- \n just asks R to make a new line



############################################################################################################
## Part 5: Use a linear model to to answer the research questions ##########################################


# -- revision: make sure you are confident about doing these things --

# -- You have seen these code moves before, in previous classes: we are strengthening skills by practising
# coding in different contexts


# -- One of our research questions is:
# # 1. What person attributes predict success in understanding?

# -- We can answer this question by examining whether a person's score on the 'HLVA' test of health literacy
# predicts, in a linear model, 'mean.acc' scores representing mean accuracy of understanding
# -- The logic is that if we have more background knowledge about health (high health literacy) then that
# should make it easier for us to understand the information in health guidance 
# -- So 'HLVA' scores should be associated -- should predict -- 'mean.acc' scores of understanding of 
# health information


# -- Task 7 -- Examine the relation between outcome ('mean.acc' mean accuracy of understanding) and 
# the predictor, health literacy 'HLVA'
# -- hint: Task 7 -- We use lm()

# -- write your code here and run it --


# -- If you look at the model summary you can answer the following questions:

# -- Q.9. -- What is the estimate for the coefficient of the effect of the predictor, 'HLVA'?

# -- Q.10. -- Is the effect significant?

# -- Q.11. -- What are the values for t and p for the significance test for the coefficient?

# -- Q.12. -- What is the adjusted R-squared value?

# -- Q.13. -- Can you express the R-squared value as a percentage?
# -- hint: Q.13. -- If R-squared is 1 then we would express that value as 100%

# -- Q.14. -- What are the F-test statistics for the model? 

# -- Q.15. -- Can you express these statistics using the conventional language shown in the week 18 lecture?


# -- hint: you may need some maths revision information, here's some:
# -- hint: on how you round numbers to some number of decimal places
# https://mathsmadeeasy.co.uk/gcse-maths-revision/rounding-numbers-gcse-math-revision/
# -- When you look at numbers like this:
# 2e-16
# -- Then you are looking at statistics expressed in "scientific notation" as is common in science
# -- In R, 2e-16 can be read as "2 x 10 to the minus 16"
# -- Here's some information on how to interpret these numbers
# https://www.open.edu/openlearn/mod/oucontent/view.php?id=68400&section=2


# -- Q.16. -- Given the results from the linear model, what is your answer to the research question?



############################################################################################################
## Part 6: Use a linear model to generate predictions ######################################################


# -- encounter: make some new moves --


# -- Task 8 -- We can use the model we have just fitted to plot the model predictions
# -- hint: Task 8 -- We are going to draw a scatterplot and add a line showing the predictions, given
# the model intercept and effect coefficient estimates


# -- First fit a model and get a summary:

# -- write your code here and run it --


# -- Q.17. -- What is the coefficient estimate for the intercept?

# -- Q.18. -- What is the estimate for the coefficient of the effect of the predictor, 'HLVA'?


# -- Second, use the geom_abline() function to draw the line:

# -- write your code here and run it --



############################################################################################################