


############################################################################################################


# In Week 18, we aim to further develop skills in visualizing *and* in analyzing psychological data

# We do this to learn how to answer research questions like:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# These kinds of research questions can often be answered through analyses using linear models
# -- We will use linear models to estimate the association between predictors and outcomes


# When we do these analyses, we will need to think about how we report the results:  
# -- we usually need to report information about the kind of model we specify;
# -- and we will need to report the nature of the association estimated in our model;
# -- we usually need to decide, is the association significant?
# -- does the association reflect a positive or negative relationship between outcome and predictor?
# -- is the association we see in our sample data relatively strong or weak?


# At every stage, as we work, we will visualize the data to:
# -- Understand the shape of the relationships we may observe or predict
# -- Evaluate our data so that we can consider the limits or biases in our sample

# As we work, we will develop skills in producing appealing plots for professional audiences 



############################################################################################################


# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# We will take things step-by-step

# -- I will be explicit about when I will ask you to:
# -- consolidate -- where you have had the chance to practice things before;
# -- revise -- where you have started to do things and maybe can use some practice to strengthen skills;
# -- encounter -- where you are doing things that are new;
# -- extend -- where you can do things that will stretch you -- where you might need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use data from a 2020 study of the response of adults from a UK national
# sample to written health information:

# study-one-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: should be no surprises here --


# -- Task 3 -- Read in the data file we will be using: 
# study-one-general-participants.csv

# -- We use the read_csv() function to read the data file into R
study.one <- read_csv("study-one-general-participants.csv")  


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- Use the summary() or head() functions to take a look
head(study.one)
summary(study.one)

# -- head() will give you the top few rows of any dataset you have read into R
# -- head(...) is a function, and you put the name of the dataset inside the brackets to
# view it
head(study.one)

# -- summary() will give you either descriptive statistics for variable columns classified as numeric
# or will tell you that columns in the dataset are not numeric
# -- summary() is also a function and, again, you put the name of the dataset inside the brackets to
# view it
summary(study.one)



############################################################################################################
## Part 3: Use histograms to examine the distributions of variables ########################################


# -- revision: practice to strengthen skills --


# -- Task 5 -- Draw histograms to examine the distributions of variables

# -- Revise editing:
# -- 1 -- the appearance of the bars using binwidth
# -- 2 -- the colour of the background using theme_bw()
# -- 3 -- the appearance of the labels using labs()
# -- 4 -- setting the x-axis limits to reflect the full range of possible scores on the x-axis variable
# -- hint: Task 5 -- You may need to refer to information about variables from the summary() results


# -- Here, we shall focus on two variables, mean accuracy of understanding ('mean.acc') and 
# mean self-rated accuracy ('mean.self')

ggplot(data = study.one, aes(x = mean.acc)) + 
  geom_histogram() +
  theme_bw() +
  labs(x = "Mean accuracy ('mean.acc')", y = "frequency count") +
  xlim(0, 1)

ggplot(data = study.one, aes(x = mean.self)) + 
  geom_histogram(binwidth = 1) +
  theme_bw() +
  labs(x = "Mean self-rated accuracy ('mean.self')", y = "frequency count") +
  xlim(0, 10)



############################################################################################################
## Part 4: Now draw scatterplots to examine associations between variables #################################


# -- revision: make sure you are confident about doing these things --


# -- Task 6 -- Create a scatterplot to examine the association between some variables

# -- Revise making edits to:
# -- 1 -- the appearance of the points using alpha, size, shape, and colour
# -- 2 -- the colour of the background using theme_bw()
# -- 3 -- the appearance of the labels using labs()
# -- 4 -- Set the x-axis and y-axis limits to the minimum-maximum ranges of the variables we plot

ggplot(data = study.one, aes(x = mean.self, y = mean.acc)) +
  geom_point(alpha = 0.5, size = 2, colour = "darkblue", shape = 'circle')   +
  theme_bw() +
  labs(x = "Mean self-rated accuracy ('mean.self')", y = "Mean accuracy ('mean.acc')") +
  xlim(0, 10) + ylim(0, 1)


# -- You can change the transparency (alpha), size, colour and shape of important parts of a plot
# -- Here, we are changing the appearance of the points
# -- But you can also change the transparency (alpha), size, colour and shape of reference lines
# added to a plot

# -- The ggplot geom_point() reference information is here: 
# https://ggplot2.tidyverse.org/reference/geom_point.html
# -- where you can see some examples of the edits we have done

# -- Some useful information about shape options is here:
# http://www.cookbook-r.com/Graphs/Shapes_and_line_types/
# -- Some useful information about shape options is here:
# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/


# -- Now experiment!



############################################################################################################
## Part 5: Use a linear model to to answer the research questions ##########################################


# -- revision: make sure you are confident about doing these things --

# -- You have seen these code moves before, in previous classes: we are strengthening skills by practising
# coding in different contexts


# -- One of our research questions is:
# 2. Can people accurately evaluate whether they correctly understand written health information?

# -- We can answer this question by examining whether mean self-rated accuracy of understanding predicts, 
# in a linear model, mean accuracy of understanding
# -- The logic is that if we can accurately rate our own understanding (from bad to good) then that rating
# should be associated -- should predict -- how accurately we can actually respond to questions that test
# that understanding



# -- Task 7 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# the predictor mean self-rated accuracy ('mean.self')
# -- hint: Task 7 -- We use lm()
model <- lm(mean.acc ~ mean.self, data = study.one)
summary(model)


# -- Notice that we do the linear model in the steps:
# -- 1 -- model <- lm(...) -- fit the model using lm(...), give the model a name -- here, we call it "model"
# -- 2 -- ...lm(mean.acc ~ mean.self...) -- tell R you want a model of the outcome 'mean.acc' predicted (~) by
# the predictor 'mean.self'
# -- 3 -- ...data = study.one) -- tell R that the variables you name in the formula live in the 
# 'study.one' dataset
# -- 4 -- summary(model) -- ask R for a summary of the model you called "model"

# -- Notice: R has a general formula syntax: outcome ~ predictor *or* y ~ x
# -- and uses the same format across a number of different functions
# -- each time, the left of the tilde symbol ~ is some output or outcome
# -- and the right of the tilde ~ is some input or predictor or set of predictors


# -- If you look at the model summary you can answer the following questions  

# -- Q.5. -- What is the estimate for the coefficient of the effect of the predictor, mean.self?
# -- A.5. -- 0.043584 

# -- Q.6. -- Is the effect significant?
# -- A.6. -- It is significant, p < .05

# -- Q.7. -- What are the values for t and p for the significance test for the coefficient?
# -- A.7. -- t = 7.194, p = 2.03e-11

# -- Q.8. -- What do you conclude is the answer to the research question, given the linear model results?
# -- A.8. -- The model slope estimate suggests that as mean.self scores increase so also do mean.acc scores



############################################################################################################
## Part 6: Use a linear model to generate predictions ######################################################


# -- encounter: make some new moves --


# -- Task 8 -- We can use the model we have just fitted to plot the model predictions
# -- hint: Task 8 -- We are going to draw a scatterplot and add a line showing the predictions, given
# the model intercept and effect coefficient estimates


# -- First fit a model and get a summary:
model <- lm(mean.acc ~ mean.self, data = study.one)
summary(model)


# -- Q.9. -- What is the coefficient estimate for the intercept?
# -- A.9. -- 0.515331

# -- Q.10. -- What is the coefficient estimate for the slope of mean.self?
# -- A.10. -- 0.043584


# -- Second, use the geom_abline() function to draw the line:
ggplot(data = study.one, aes(x = mean.self, y = mean.acc)) +
  geom_point(alpha = 0.5, size = 2, colour = "blue", shape = 'circle')   +
  geom_abline(intercept = 0.515331, slope = 0.043584, colour = "red", size = 1.5) +
  theme_bw() +
  labs(x = "Mean self-rated accuracy ('mean.self')", y = "mean accuracy ('mean.acc')")


# -- You can see that all we do is:
# -- add the geom_abline(...) function
# -- and in that, add information about the intercept and the slope

# -- See reference information here:  
#   https://ggplot2.tidyverse.org/reference/geom_abline.html      


# -- Note that we can get the prediction line drawn for us automatically, as:
ggplot(data = study.one, aes(x = mean.self, y = mean.acc)) +
  geom_point(alpha = 0.5, size = 2, colour = "blue", shape = 'circle')   +
  geom_smooth(method = 'lm', colour = "purple", alpha = .2, size = 2.5, se = FALSE) +
  theme_bw() +
  labs(x = "Mean self-rated accuracy ('mean.self')", y = "mean accuracy ('mean.acc')")

# -- Here, I added geom_smooth(method = 'lm', ...) to draw a prediction line
# -- You can compare the red prediction line I drew using the model estimates
# -- with the purple line I used geom_smooth() to draw automatically
# -- to see that they are identical

# -- This shows you something of what geom_smooth() does
# -- It is very useful:
# https://ggplot2.tidyverse.org/reference/geom_smooth.html



############################################################################################################