


############################################################################################################


# In Week 19, we aim to use our skills in visualizing *and* in analyzing psychological data
# to answer our research questions:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# -- We will use linear models to estimate the association between predictors and outcomes

# -- What is new, here, is firstly that:
# -- we will fit linear models including *multiple* predictors;
# -- this is why this form of analysis is also often called "multiple regression"

# -- Secondly, we will compare the results from different studies to critically examine questions relating to
# results reproducibility:
# -- do we see the same results when similar methods are used to collect data to address the same
# questions?

# As we work, we will develop skills in producing appealing plots for professional audiences 
# As we work, we will also practise how we can ensure that the code we write to do data analysis
# is reproducible, and shareable
# -- This is about open science good practice
# -- And it is about getting ready for professional team working



############################################################################################################


# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# We will take things step-by-step

# -- I will be explicit about when I will ask you to:
# -- consolidate -- where you have had the chance to practice things before;
# -- revise -- where you have started to do things and maybe can use some practice to strengthen skills;
# -- encounter -- where you are doing things that are new;
# -- extend -- where you can do things that will stretch you -- where you might need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggeffects")
library("patchwork")
library("tidyverse")

# -- Notice: here we are working with 'tidyverse' as usual but also now 'patchwork' and 'ggeffects'
# -- This is new but these libraries are installed in R-Studio for you, you just need
# to run the library() function to make them available for the session



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use data from two 2020 studies of the response of adults from a UK national
# sample to written health information:

# study-one-general-participants.csv
# study-two-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: should be no surprises here --


# -- Task 3 -- Read in the data file we will be using: 
# study-one-general-participants.csv

# -- We use the read_csv() function to read the data file into R
study.one <- read_csv("study-one-general-participants.csv")  
study.two <- read_csv("study-two-general-participants.csv")  


# -- Notice what is new, here:
# -- we are working with two datasets in the same script and the same R session 
# -- to do this effectively, we make sure that the different datasets get different names


# -- Task 4 -- Inspect the data files
# -- hint: Task 4 -- Use the summary() function to take a look
summary(study.one)
summary(study.two)

# -- A quick inspection of the results of these two summaries should show you:
# -- the datasets are similar -- you can see the same columns -- the same layout  
# -- the datasets have some differences -- apparent in the values for the summary
# statistics



############################################################################################################
## Part 3: Use histograms to examine the distributions of variables ########################################


# -- revision: practice to strengthen skills --


# -- Task 5 -- Draw histograms to examine the distributions of variables


# -- Here, we shall focus on one variable, mean accuracy of understanding ('mean.acc')
# -- But -- this is new -- we look at the distribution of the same variable in data from
# two different but similar studies

ggplot(data = study.one, aes(x = mean.acc)) + 
  geom_histogram() +
  theme_bw() +
  labs(x = "Mean accuracy ('mean.acc')", y = "frequency count") +
  xlim(0, 1)

ggplot(data = study.two, aes(x = mean.acc)) + 
  geom_histogram() +
  theme_bw() +
  labs(x = "Mean accuracy ('mean.acc')", y = "frequency count") +
  xlim(0, 1)

# -- You can use the arrows at the top of the R-Studio Plots window to flip backwards and forwards
# between the plots, to compare the distributions of mean accuracy scores from the two studies


# -- This method of comparing plots is OK but we can do better


# -- encounter: make some new moves --


# -- Task 6 -- Write code to first create plots and second show the plots side-by-side for comparison
# -- hint: Task 6 -- We want comparison plots, we proceed in two steps

# -- First, write code to create -- but not show -- two plots
study.one.histogram <- ggplot(data = study.one, aes(x = mean.acc)) + 
                         geom_histogram() +
                         theme_bw() +
                         labs(x = "Mean accuracy ('mean.acc')", y = "frequency count") +
                         ggtitle("Study one") +                       
                         xlim(0, 1)

study.two.histogram <- ggplot(data = study.two, aes(x = mean.acc)) + 
                         geom_histogram() +
                         theme_bw() +
                         labs(x = "Mean accuracy ('mean.acc')", y = "frequency count") +
                         ggtitle("Study two") +
                         xlim(0, 1)

# -- second, show the plots side-by-side
study.one.histogram + study.two.histogram

# Note what we is different here:

# -- 1 -- study.one.histogram <- ggplot(...) ...
# -- We create a plot object using ggplot(...) just as we have done before
# -- But now we do not draw it or show it: nothing happens in Plot window, yet, when we run
# this chunk of code
# -- Critically, we give the plot object a distinct name

# -- 2 -- We do this to create two plots

# -- 3 -- study.one.histogram + study.two.histogram
# -- We then add the first plot + to the second plot
# -- And running this line of code is what triggers the production of the plots, showing them
# side-by-side, for easier comparison, in the Plot window


# -- In doing this work, we are using a very powerful library of functions
# -- Take a look at the things you can do:
# https://patchwork.data-imaginist.com


# -- Now you can answer questions like the following

# -- Q.1. -- What differences do you see when you compare the distributions?
# -- A.1. -- The peaks of the distributions are in (slightly) different places
# -- hint: A.1. -- Take a look at the summaries, the means should be different for 'mean.acc'
# for the two studies

# -- Q.2. -- What similarities do you see when you compare the distributions?
# -- A.2. -- The distributions are similar:
# -- 'mean.acc' scores are largely confined, in both studies, to values > .50
# -- there is a bit more skew for study one than for study two data, with a few more
# people maybe showing lower levels of accuracy

# -- Q.3. -- What are the reasons for the differences or similarities?
# -- A.3. -- We can speculate but it is hard to explain the differences or similarities
# -- Participants from both studies were recruited through the same Prolific
# online data collection platform and fit the same profile: adults living in the UK who
# speak English
# -- The differences between samples are maybe just random



############################################################################################################
## Part 4: Now draw scatterplots to examine associations between variables #################################


# -- consolidate: practice to strengthen skills --


# -- Task 6 -- Create a scatterplot to examine the association between some variables

# -- Consolidate on creating two plots that you show side-by-side for comparison

# -- First, as before, begin by creating two plot objects, with distinct names, and titles
study.one.scatter <- ggplot(data = study.one, aes(x = mean.self, y = mean.acc)) +
                       geom_point(alpha = 0.5, size = 2, colour = "darkgrey", shape = 'circle') +
                       geom_smooth(method = "lm", se = FALSE, colour = "red") +                     
                       theme_bw() +
                       labs(x = "Mean self-rated accuracy ('mean.self')", y = "Mean accuracy ('mean.acc')") +
                       ggtitle("Study one") +
                       xlim(0, 10) + ylim(0, 1)

study.two.scatter <- ggplot(data = study.two, aes(x = mean.self, y = mean.acc)) +
                       geom_point(alpha = 0.5, size = 2, colour = "darkblue", shape = 'circle') +
                       geom_smooth(method = "lm", se = FALSE, colour = "red") +
                       theme_bw() +
                       labs(x = "Mean self-rated accuracy ('mean.self')", y = "Mean accuracy ('mean.acc')") +
                       ggtitle("Study two") +
                       xlim(0, 10) + ylim(0, 1)

# -- Second, write code to show both plots
study.one.scatter + study.two.scatter


# -- Remember:

# -- You can change the transparency (alpha), size, colour and shape of important parts of a plot

# -- The ggplot geom_point() reference information is here: 
# https://ggplot2.tidyverse.org/reference/geom_point.html
# -- where you can see some examples of the edits we have done

# -- Some useful information about shape options is here:
# http://www.cookbook-r.com/Graphs/Shapes_and_line_types/
# -- Some useful information about shape options is here:
# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/


# -- Now you can answer these questions


# -- Q.4. -- What is the nature of the relationship between 'mean.self' and 'mean.acc'?
# -- A.4. -- It can be seen that higher levels of 'mean.self' are associated with higher 'mean.acc' scores

# -- Q.5. -- What does this suggest is the answer to the research question:
# # 2. Can people accurately evaluate whether they correctly understand written health information?
# -- A.5. -- The plots suggest that we can -- to some extent -- accurately evaluate whether we correctly
# understand health information
# -- This is because the data suggest that we *do* score better on tests of understanding when we 
# say -- in self-evaluation ratings -- that we think we understand the information better

# -- Q.6. -- Do the plots indicate any reasons to put critical limits on our conclusions?
# -- A.6. -- Yes, notice:
# -- If you compare the plots, you can see there is quite a bit of variation between studies, 
# suggesting that whatever the true relationship is, our picture of it will vary between
# datasets: there is some uncertainty over what we can see, given our data
# -- If you look at each plot, you can see that within a study dataset, there are many people who
# vary in different ways from the predicted relation between 'mean.self' and 'mean.acc'
# -- This suggests that:
# (i.) there may be a relationship but it does not capture all that is influencing how well we can 
# predict how accurately we understand something, and 
# (ii.) it may
# be the case that some people are better and some people are worse at evaluating their own
# understanding



############################################################################################################


# -- Notice that drawing grids of plots to allow comparisons of trends or patterns between datasets
# is a technique -- using 'small multiples' -- in advanced professional data visualization
# -- I discuss this in the week 17 lecture on data visualization



############################################################################################################
## Part 5: Now draw boxplots to examine associations between variables #####################################


# -- consolidate: practice to strengthen skills --


# -- Task 7 -- Create boxplots to examine the association between a continuous numeric outcome variable
# like 'mean.acc' and a categorical variable like 'ETHNICITY'
# -- hint: Task 7 -- Notice here that we use geom_boxplot()
# -- hint: Task 7 -- We can see where variables are not numeric using:
summary(study.one)


# -- The basic boxplot can be produced using code like this:
ggplot(data = study.one, aes(x = ETHNICITY, y = mean.acc)) +
  geom_boxplot() +
  theme_bw() +
  labs(x = "Ethnicity, ONS categories", y = "Mean accuracy of understanding ('mean.acc')") +
  ylim(0, 1.1)

# -- 1 -- ggplot(data = study.one, aes(x = ETHNICITY, y = mean.acc)) +
# -- You define two aesthetic mappings:
# x = ETHNICITY -- the x variable has to be categorical or nominal, a factor like 'ETHNICITY' with different levels
# -- Here, there are different factor levels corresponding to different ethnicity groups
# y = mean.acc -- the y variable has to be numeric, a set of numbers like 'mean.acc' with different values
# -- 2 -- geom_boxplot() +
# -- Information about category (x = ...) and outcome (y = ...) is fed into geom_boxplot() to draw a box to represent
# the distribution of outcome scores for each group

# -- Notice:
# -- the middle line in each box represents the median outcome (here 'mean.acc') score for each group
# -- the shape of the box represents the distribution or spread of scores, the top of the box represents the 75th percentile
# (what the score is for the people who are at the top 75% of the sample) and the bottom of the box represents the 25th percentile
# (what the score is for the people at the 25% level of outcomes for the sample)


# -- More information about boxplots can be found here:
# https://ggplot2.tidyverse.org/reference/geom_boxplot.html


# -- Here is an edit of the plot to make it a bit more effective:
ggplot(data = study.one, aes(x = ETHNICITY, y = mean.acc)) +
  geom_jitter(alpha = .5) +
  geom_boxplot(outlier.shape = NA, colour = "red", alpha = .1) +
  theme_bw() +
  labs(x = "Ethnicity, ONS categories", y = "Mean accuracy of understanding ('mean.acc')") +
  ylim(0, 1.1)

# -- The plot shows:
# -- boxplots to indicate the average (median) and spread (percentiles) in 'mean.acc' scores for each group;
# -- plus, with points, individual 'mean.acc' scores for the people in each group
   

# -- Now you can use the plots to answer questions like the following


# -- Q.7. -- What do you notice about the distribution of scores in different groups?
# -- A.7. -- The average accuracy of understanding appears to be similar between groups

# -- Q.8. -- Does anything in the plots give you reason to question the nature of the participant sample?
# -- A.8. -- This is a leading question -- there is plenty in the plots to cause concern:
# -- The scatter of points shows that we have many more "White" participants in the sample than participants
# from other ethnicities
# -- Because we have very few people in the study from BAME groups, we might be concerned about whether the results
# from our models are representative of what you would see in these groups, or whether the results
# are representative of the wider population in general

# -- Q.9. -- Can you use the ggplot() reference information -- see the webpage link -- to see how
# and why I made the code edits I did?
# -- A.9. -- You can see example code for each edit in the webpage  
  
# -- Q.10. -- Do you understand what geom_jitter() is doing? -- and why I would use it?  
# -- A.10. -- What the function does, and why I would use it can be found in the reference information webpage:
# https://ggplot2.tidyverse.org/reference/geom_jitter.html



############################################################################################################


# -- Notice that drawing plots which show *both* summaries (like boxplots) and raw data (scores as points)
# -- Is another common professional visualization technique
# -- It is effective because these kinds of plots help you to see the pattern or trend *and* 
# the nature of the underlying sample  



############################################################################################################
## Part 6: Use a linear model to to answer the research questions ##########################################


# -- revision: make sure you are confident about doing these things --


# -- One of our research questions is:
# 2. Can people accurately evaluate whether they correctly understand written health information?

# -- We can answer this question by examining whether mean self-rated accuracy of understanding predicts, 
# in a linear model, mean accuracy of understanding


# -- Task 8 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# the predictor mean self-rated accuracy ('mean.self')
# -- Do this for both datasets
# -- hint: Task 8 -- We use lm()

model.one <- lm(mean.acc ~ mean.self, data = study.one)
summary(model.one)

model.two <- lm(mean.acc ~ mean.self, data = study.two)
summary(model.two)

# -- Notice:
# -- you have to be *careful* here -- make sure the lm(data = ...) bit refers correctly by name to the different
# datasets
# -- you have to be *careful* here -- make sure the models get different names, matching the datasets


# -- If you look at the model summaries you can answer the following questions  

# -- Q.11. -- What is the estimate for the coefficient of the effect of the predictor, mean.self, in study.one?
# -- A.11. -- 0.043584 

# -- Q.12. -- What is the estimate for the coefficient of the effect of the predictor, mean.self, in study.two?
# -- A.12. -- 0.053566 

# -- Q.13. -- Are these effects significant?
# -- A.13. -- They are both significant, p < .05

# -- Q.14. -- What is the adjusted R-squared for the study.one model?
# -- A.14. -- For study.one data, for the model, adjusted R-squared = .232 -- the model explains about 23% of 
# outcome 'mean.acc' variance

# -- Q.15. -- What is the adjusted R-squared for the study.two model?
# -- A.15. -- For study.two data, for the model, adjusted R-squared = .2941 -- the model explains about 29% of 
# outcome 'mean.acc' variance

# -- Q.16. -- Do you think that in both studies we see similar or different relationships between self-rated
# evaluations of understanding and performance on tests of that understanding?
# -- A.16. -- The model slope estimate suggests that as mean.self scores increase so also do mean.acc scores
# for both studies
# -- This suggests the relationship is replicated between studies
# -- But there is some variation between in studies in the exact estimate for the relationship and it would be 
# good to know what causes this variation, if it is not random


# -- encounter: make some new moves --


# -- Task 9 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# multiple different predictors
# -- Do this for both datasets
# -- hint: Task 9 -- We use lm()


# -- The first of our research questions is:
# 1. What person attributes predict success in understanding?

# -- Given our theoretical understanding of how reading comprehension works, we can expect that variation
# in a number of different measures of skill or knowledge should predict variation in accuracy of
# understanding
# -- We can fit a linear model including multiple predictors to estimate the "effects" of all these
# variables together
model.one.acc <- lm(mean.acc ~ AGE + SHIPLEY + HLVA + FACTOR3 + QRITOTAL,
            data = study.one)
summary(model.one.acc)

# -- Notice:
# -- We use the same lm() function that we did before
# -- What is new here is that we expand the model formula to include each of multiple predictors
# AGE + SHIPLEY + HLVA + FACTOR3 + QRITOTAL
# -- each predictor is specified by name, and names are separated by +s


# -- Q.17. -- Can you now fit the same model -- same predictors -- for the study.two dataset?
# -- A.17. -- You just need to change the dataset name:
model.two.acc <- lm(mean.acc ~ AGE + SHIPLEY + HLVA + FACTOR3 + QRITOTAL,
                    data = study.two)
summary(model.two.acc)


# -- Now let's focus on extracting and reporting the results of an analysis like this


# -- Q.18. -- Look at the model.one.acc results summary, can you identify:

# -- Q.18.1. -- Adjusted R-squared?
# -- A.18.1 -- Adjusted R-squared = 0.3513; what is this as a percentage? Adj.R-sq = 35.1%

# -- Q.18.2. -- F-test results?  
# -- A.18.2. -- F(5, 163) = 19.19, p < .001

# -- Q.18.3. -- The significant coefficients
# -- A.18.3. -- The significant coefficients are for HLVA, FACTOR3, and QRITOTAL
# -- We usually ignore the intercept

# -- Q.18.4. -- The nature of the relationships suggested by the significant coefficients?
# -- A.18.4. -- The significant coefficients are all positive numbers, suggesting that
# people with higher scores on HLVA (health literacy), reading strategy (FACTOR3) and
# reading comprehension skill (QRITOTAL), tend to be more accurate in tests of understanding of
# written health information


# -- Q.19. -- Can you identify the same information for the model of study.two data?

# -- Q.19.1. -- Adjusted R-squared?
# -- A.19.1 -- Adjusted R-squared = 0.4189; what is this as a percentage? Adj.R-sq = 41.9%

# -- Q.19.2. -- F-test results?  
# -- A.19.2. -- F(5, 166) = 25.65, p < .001

# -- Q.19.3. -- The significant coefficients
# -- A.19.3. -- The significant coefficients are for SHIPLEY, HLVA, FACTOR3, and QRITOTAL
# -- We usually ignore the intercept

# -- Q.18.4. -- The nature of the relationships suggested by the significant coefficients?
# -- A.18.4. -- The significant coefficients are all positive numbers, suggesting that
# people with higher scores on SHIPLEY (vocabulary), HLVA (health literacy), reading strategy (FACTOR3) and
# reading comprehension skill (QRITOTAL), tend to be more accurate in tests of understanding of
# written health information


# -- Q.20. -- Can you compare the results from the analyses of the data from the two studies?
# -- hint: Q.20. -- Does the comparison indicate similarities or differences between results?
# -- A.20. -- We can see similarities *and* differences in results
# -- Health literacy, reading strategy and reading skill appear to influence accuracy of understanding
# in both studies
# -- Age is not influential in both studies
# -- Vocabulary appears to be imporant in study.one but not study.two data: why not?
# -- Model variance explained -- R-squared -- is greater in study two

# -- There is some variation between the studies but can you see how similar the coefficient estimates are?



############################################################################################################


# -- Notice that in these kinds of comparisons -- of the results of analyses -- we are examining:

# -- first, the stability of results -- and how results may vary given different analysis choices
# -- this connects to ideas about (methods) reproducibility or replication discussed in the lecture and 
# in other modules

# -- second, the stability or reproducibility of results
# -- we can compare the results from different studies -- and often do, in psychology -- in an effort
# to identify if critical effects are reproducible across different studies, different samples,
# different kinds of participants
# -- these questions connect to discussions of replication in the lecture and in other modules

# -- We do this to establish or critically evaluate our evidence



############################################################################################################
## Part 7: Use a linear model to generate predictions ######################################################


# -- encounter: make some new moves --


# -- Task 10 -- We can use the model we have just fitted to plot the model predictions

# -- In week 18, we saw how you can use geom_abline() to get and visualize 
# model predictions for the situation in which you have a model with one outcome and one 
# predictor variable
# -- This week, we see how you can use the function ggpredict() from the ggeffects library
# to the same job, for the more complex situation in which you have a model with one outcome
# and multiple predictor variables

# -- We create the plot in three steps:

# -- First: fit a model -- and give the model object a name:
model <- lm(mean.acc ~ AGE + SHIPLEY + HLVA + FACTOR3 + QRITOTAL, 
            data = study.one)

# -- Second, generate the predictions, specifying the variable or effect you want predictions for
# by specifying the name of the variable in ggpredict(... terms = ...)
dat <- ggpredict(model, terms = "AGE")

# -- Third, draw a plot to show the predictions
p.AGE <- plot(dat)
p.AGE +
  geom_point(data = study.one, aes(x = AGE, y = mean.acc), 
             alpha = .5, size = 1.5, colour = "darkgrey") +
  geom_line(size = 1.5) +
  ylim(0, 1.1)+
  theme_bw() +
  labs(x = "Age (years)", y = "Comprehension accuracy")

# -- Notice:
# -- We first create a set of predictions -- we call 'dat' -- using ggpredict()
# -- We then create a plot, using plot(dat), asking the plot() function to work with the set
# of predictions 'dat'
# -- Note that:
# p.AGE <- plot(dat)
# -- creates the basic plot
# -- While the chunk of code:
#   p.AGE +
#   geom_point(data = study.one, aes(x = AGE, y = mean.acc), 
#              alpha = .5, size = 1.5, colour = "darkgrey") +
#   geom_line(size = 1.5) +
#   ylim(0, 1.1)+
#   theme_bw() +
#   labs(x = "Age (years)", y = "Comprehension accuracy")
# -- adds details like
# geom_point(...) to show the raw data from the study.one dataset
# geom_line(...) to show the predictions from the model


# -- You can find more information on the ggeffects library here:
# https://strengejacke.github.io/ggeffects/articles/introduction_plotmethod.html


# -- Q.21. -- Can you draw a prediction plot for any other variable?
# -- A.21. -- For example, a plot of the prediction given the model estimate for the HLVA effect
model <- lm(mean.acc ~ AGE + SHIPLEY + HLVA + FACTOR3 + QRITOTAL, 
            data = study.one)

dat <- ggpredict(model, terms = "HLVA")

p.HLVA <- plot(dat)
p.HLVA +
  geom_point(data = study.one, aes(x = HLVA, y = mean.acc), 
             alpha = .5, size = 1.5, colour = "darkgrey") +
  geom_line(size = 1.5) +
  ylim(0, 1.1)+
  theme_bw() +
  labs(x = "Health literacy (HLVA)", y = "Comprehension accuracy")

# -- Notice:
# -- To draw a prediction plot for another variable, just change the name of the model term, and then
# edit the plot geom_point(...x = ...) and labs(...) parts

# -- Q.22. -- Can you interpret the model summary results coefficient for the effect of HLVA
# given what you see in the plot?
# -- A.22. -- The model summary is produced by:
model <- lm(mean.acc ~ AGE + SHIPLEY + HLVA + FACTOR3 + QRITOTAL, 
            data = study.one)
summary(model)
# -- This shows that the coefficient estimate for the HLVA effect in the study.one dataset is: 0.0166239
# -- The plot shows that for higher HLVA scores, we can see increasing levels of comprehension accuracy

# -- Q.23. -- Now, can you do the same, yourself, for a different variable?

# -- Q.25. -- What about doing the same for the same or different variables for the study.two dataset?



############################################################################################################
## Optional: Export a plot so you can use it in a report ###################################################


# -- encounter: make some new moves --


# -- Task 11 -- Can you export a plot so that you can use it in a report?
# -- hint: Task 11 -- There are different ways to do this, we shall look at two


# -- 1 -- Click on the Export button at the top of the Plots window and save the image


# -- 2 -- We can use ggsave() -- this works in two steps:

# -- First, draw the plot:
ggplot(data = study.two, aes(x = mean.self, y = mean.acc)) +
  geom_point(alpha = 0.5, size = 2, colour = "darkblue", shape = 'circle') +
  geom_smooth(method = "lm", se = FALSE, colour = "red") +
  theme_bw() +
  labs(x = "Mean self-rated accuracy ('mean.self')", y = "Mean accuracy ('mean.acc')") +
  ggtitle("Study two") +
  xlim(0, 10) + ylim(0, 1)

# -- Second, use ggsave() to save it:
ggsave("study.two-scatter-mean-acc-self.pdf", width = 20, height = 20, units = "cm")

# -- Notice:
# -- By default, ggsave() will save the last plot you draw
# -- You should give the plot a name
# -- You can draw plots in different image file formats, here, I use .pdf
# -- You need to define the width and height of the plot image

# -- The plot will be saved to your working directory: usually the folder your script is in

# -- You can see more information about ggsave() here:
# https://ggplot2.tidyverse.org/reference/ggsave.html


# -- Notice:
# -- Just as we did earlier, we can generate multiple plots and use patchwork to produce
# a grid of prediction plots
# -- This is what I did to create images in the week 19 lecture slides 
# -- Can you work out how to do this?  



############################################################################################################