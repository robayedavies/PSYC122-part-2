


############################################################################################################


# In Week 17, we aim to further develop skills in visualizing psychological data

# We do this to learn how to answer research questions like:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# These kinds of research questions can be answered using methods like correlation and linear models

# We will consolidate and *extend* learning on data visualization:
# -- Use histograms to examine the distributions of variables;
# -- Use boxplots to examine the differences between groups on a variable;
# -- Use scatterplots to examine how values on one variable relate to values on another variable;
# -- Learn to edit the scatterplots
# -- Learn to edit the histograms

# We will also do some revision on using the correlation test to examine associations between variables



############################################################################################################


# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# We will take things step-by-step

# -- I will be explicit about when I will ask you to:
# -- consolidate -- where you have had the chance to practice things before;
# -- revise -- where you have started to do things and maybe can use some practice to strengthen skills;
# -- encounter -- where you are doing things that are new;
# -- extend -- where you can do things that will stretch you -- where you might need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use data from a 2020 study of the response of adults from a UK national
# sample to written health information:

# study-one-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: should be no surprises here --


# -- Task 3 -- Read in the data file we will be using: 
# study-one-general-participants.csv

# -- We use the read_csv() function to read the data file into R
study.one <- read_csv("study-one-general-participants.csv")  


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- Use the summary() or head() functions to take a look
head(study.one)
summary(study.one)

# -- head() will give you the top few rows of any dataset you have read into R
# -- head(...) is a function, and you put the name of the dataset inside the brackets to
# view it
head(study.one)

# -- summary() will give you either descriptive statistics for variable columns classified as numeric
# or will tell you that columns in the dataset are not numeric
# -- summary() is also a function and, again, you put the name of the dataset inside the brackets to
# view it
summary(study.one)



############################################################################################################
## Part 3: Visualize data ##################################################################################


# -- Task 5 -- Visualize the distribution of the `mean.self` self-rated accuracy scores
# -- hint Task.5 -- Use geom_histogram()
ggplot(data = study.one, aes(x = mean.self)) +
  geom_histogram()


# -- Task 6 -- Show the self-rated accuracy recorded for individuals of different genders
# -- hint Task.6 -- Use geom_boxplot() and start by defining aes(x = GENDER, y = mean.self)
ggplot(data = study.one, aes(x = GENDER, y = mean.self)) +
  geom_boxplot()


# -- Task 7 -- Show the relationship between mean.self and health literacy (HLVA)
# -- hint Task.7 -- Use geom_point()
ggplot(data = study.one, aes(x = HLVA, y = mean.self)) +
  geom_point()



############################################################################################################
## Part 4: Now draw and edit scatterplots to examine associations between variables ########################


# -- revision: make sure you are confident about doing these things --

# -- You have seen these code moves before, in previous classes: we are strengthening skills by practising
# coding in different contexts


# -- Task 8 -- Create a scatterplot to examine the association between some variables
# -- hint: Task 8 -- We are working with geom_point() and you need x and y aesthetic mappings
ggplot(data = study.one, aes(x = mean.self, y = mean.acc)) +
  geom_point()

# -- This plot shows:
# -- the possible association between x-axis variable 'mean.self' and y-axis variable 'mean.acc'

# -- The plot code moves through the following steps:  
# -- 1 -- ggplot(...) -- make a plot
# -- 2 -- ggplot(data = study.one, ...) -- with the 'study.one' dataset
# -- 3 -- ggplot(...aes(x = mean.self, y = mean.acc)) -- using two aesthetic mappings:
# -- x = mean.self -- map 'mean.self' values to x-axis (horizontal, left to right) positions
# -- y = mean.acc -- map 'mean.acc' values to y-axis (vertical, bottom to top) positions
# -- 4 -- geom_point() -- show the mappings as points    


# -- Task 9 -- Now do scatterplots with any pair of numeric variables you like  
# -- hint: Task 9 -- Remember what we saw with summary() not every variable consists of numbers  
# -- hint: Task 9 -- Here are some examples: experiment with other pairs of numeric variables
ggplot(data = study.one, aes(x = AGE, y = mean.self)) +
  geom_point()  

ggplot(data = study.one, aes(x = SHIPLEY, y = mean.self)) +
  geom_point()  



############################################################################################################
## Part 5: Edit the scatterplots to make them look good ####################################################


# -- encounter: make some new moves --


# -- Task 10 -- Edit the appearance of the plot step-by-step


# -- We are going to edit:
# -- 1 -- the appearance of the points using alpha and size
# -- 2 -- the colour of the background using theme_bw()
# -- 3 -- the appearance of the labels using labs()
# -- as follows

# -- 1 -- the appearance of the points using alpha and size
ggplot(data = study.one, aes(x = HLVA, y = mean.self)) +
  geom_point(alpha = 0.5, size = 2) 

# -- 2 -- the colour of the background using theme_bw()
ggplot(data = study.one, aes(x = HLVA, y = mean.self)) +
  geom_point(alpha = 0.5, size = 2)  +
  theme_bw()

# -- 3 -- the appearance of the labels using labs()
ggplot(data = study.one, aes(x = HLVA, y = mean.self)) +
  geom_point(alpha = 0.5, size = 2)  +
  theme_bw() +
  labs(x = "HLVA", y = "mean self rated accuracy")


# -- The arguments alpha and size can change the appearance of most geometric objects (geoms) in ggplot:
# -- in the code example, here, we vary the alpha number to change how opaque or transparent the points are
# -- we vary the size number to vary the size of the points.

# -- It helps to modify alpha when we have a lot of points because then you can see where a bunch of points
# are clustered together.


# -- Task 11 -- Now you experiment: edit the appearance of the plot by changing alpha and size -- what about
# colour?
# -- hint: Task 11 -- Check out the ggplot reference for scatterplots


# -- Q.1. -- Can you find the ggplot reference page?
# -- hint: Q.1 -- Do a search with the keywords "ggplot reference geom_point"
# -- A.1. -- It is here: 
# https://ggplot2.tidyverse.org/reference/geom_point.html

# -- Q.2. -- Can you change the colour of the points to a colour you like?
# -- hint: Q.2. -- Useful information on colour can be found here:
# https://r-graphics.org/recipe-colors-setting
# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
ggplot(data = study.one, aes(x = HLVA, y = mean.self)) +
  geom_point(alpha = 0.5, size = 2, colour = "hotpink")  +
  theme_bw() +
  labs(x = "HLVA", y = "mean self rated accuracy")


# -- Now you try: experiment with alpha, size, colour, labels



############################################################################################################
## Part 6: Edit histograms to examine distributions and make the plots look good ###########################


# -- revision: make sure you are confident about doing these things --


# -- Like any language, you can use some of the same code words in different contexts
# -- Here, we edit histograms: notice the similarities from when we edited scatterplots


# -- Task 12 -- Practice editing the appearance of the plot step-by-step

# -- If we break plot code into steps, it will make it easier to read, and it will make it easier to add
# edits

# -- We are going to practise editing:
# -- 1 -- the appearance of the bars using binwidth
# -- 2 -- the colour of the background using theme_bw()
# -- 3 -- the appearance of the labels using labs()
# -- Then we are going to try some new moves:
# -- 4 -- setting the x-axis limits to reflect the full range of possible scores on the x-axis variable

# -- 1 -- the appearance of the bars using binwidth
ggplot(data = study.one, aes(x = SHIPLEY)) + 
  geom_histogram(binwidth = 2)

# -- 2 -- the colour of the background using theme_bw()
ggplot(data = study.one, aes(x = SHIPLEY)) + 
  geom_histogram(binwidth = 2) +
  theme_bw()

# -- 3 -- the appearance of the labels using labs()
ggplot(data = study.one, aes(x = SHIPLEY)) + 
  geom_histogram(binwidth = 2) +
  theme_bw() +
  labs(x = "mean accuracy", y = "frequency count")


# -- encounter: make some new moves --


# -- 4 -- setting the x-axis limits using x.lim()
ggplot(data = study.one, aes(x = SHIPLEY)) + 
  geom_histogram(binwidth = 2) +
  theme_bw() +
  labs(x = "Vocabulary (SHIPLEY)", y = "frequency count") +
  xlim(0,40)


# -- We can define the limits on the x-axis and on the y-axis
# -- See ggplot reference information on setting limits here:
# https://ggplot2.tidyverse.org/reference/lims.html

# -- It is often useful to do this:
# -- 1 -- because we want to show the audience where the sample values are distributed compared
# to where they *could* be distributed, given the measure
# -- this makes sense e.g. if you want to see the relative age distribution of a sample
# compared to the population
# -- 2 -- because we want plots, shown side by side to be directly comparable
# -- 3 -- and because we want to give the audience a more accurate picture of the data



############################################################################################################
## Part 7: Use correlation to to answer the research questions #############################################


# -- revision: make sure you are confident about doing these things --

# -- You have seen these code moves before, in previous classes: we are strengthening skills by practising
# coding in different contexts


# -- One of our research questions is:
# 2. Can people accurately evaluate whether they correctly understand written health information?

# -- We can answer this question by examining whether mean self-rated accuracy of understanding correlates
# with mean accuracy of understanding
# -- The logic is that if we can accurately rate our own understanding (from bad to good) then that rating
# should be associated -- should be correlated with -- how accurately we can actually respond to questions 
# that test that understanding


# -- Task 13 -- Examine the correlation between mean self-rated accuracy ('mean.self') and mean accuracy ('mean.acc')
# -- hint: Task 13 -- We use cor.test()
cor.test(study.one$mean.acc, study.one$mean.self, method = "pearson",  alternative = "two.sided")

# -- Q.3. -- What is r, the correlation coefficient?
# -- A.3. -- r = 0.4863771
# -- Q.4. -- Is the correlation significant?
# -- A.4. -- r is significant
# -- Q.5. -- What are the values for t and p for the significance test for the correlation?
# -- A.5. -- t = 7.1936, p = 2.026e-11

# -- Q.6. -- What do you conclude, given the correlation results?
# -- hint: Q.6 -- Maybe draw a scatterplot to examine the shape of the association
# -- A.6. -- mean.acc and mean.self are positively correlated suggesting that as mean.acc scores increase so also do
# mean.self scores



############################################################################################################