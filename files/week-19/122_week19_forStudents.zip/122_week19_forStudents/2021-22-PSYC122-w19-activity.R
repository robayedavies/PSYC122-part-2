


############################################################################################################


# In Week 19, we aim to use our skills in visualizing *and* in analyzing psychological data
# to answer our research questions:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# -- We will use linear models to estimate the association between predictors and outcomes

# -- What is new, here, is firstly that:
# -- we will fit linear models including *multiple* predictors;
# -- this is why this form of analysis is also often called "multiple regression"

# -- Secondly, we will compare the results from different studies to critically examine questions relating to
# results reproducibility:
# -- do we see the same results when similar methods are used to collect data to address the same
# questions?

# As we work, we will develop skills in producing appealing plots for professional audiences 
# As we work, we will also practise how we can ensure that the code we write to do data analysis
# is reproducible, and shareable
# -- This is about open science good practice
# -- And it is about getting ready for professional team working



############################################################################################################


# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# We will take things step-by-step

# -- I will be explicit about when I will ask you to:
# -- consolidate -- where you have had the chance to practice things before;
# -- revise -- where you have started to do things and maybe can use some practice to strengthen skills;
# -- encounter -- where you are doing things that are new;
# -- extend -- where you can do things that will stretch you -- where you might need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggeffects")
library("patchwork")
library("tidyverse")

# -- Notice: here we are working with 'tidyverse' as usual but also now 'patchwork' and 'ggeffects'
# -- This is new but these libraries are installed in R-Studio for you, you just need
# to run the library() function to make them available for the session



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use data from two 2020 studies of the response of adults from a UK national
# sample to written health information:

# study-one-general-participants.csv
# PSYC122-2022.csv


# -- Notice that 'PSYC122-2022.csv' is the data recorded from the responses of PSYC122 students


# -- Be aware: in the following questions, I am going to refer to the datasets as
# 'psyc122' and 'study.one'



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: should be no surprises here --


# -- Task 3 -- Read in the data files we will be using: 
# study-one-general-participants.csv
# PSYC122-2022.csv

# -- write your code here and run it --


# -- Notice what is new, here:
# -- we are working with two datasets in the same script and the same R session 
# -- to do this effectively, we make sure that the different datasets get different names


# -- Task 4 -- Inspect the data files
# -- hint: Task 4 -- Use the summary() function to take a look

# -- write your code here and run it --


# -- How do the 'psyc122' and 'study.one' datasets compare?


# -- Q.1. -- What is the number of observations in the 'study.one' dataset compared to the 'psyc122' dataset?

# -- Q.2. -- What is the mean of 'mean.acc' in each dataset?

# -- Q.3. -- Take a look at the summary() mean values for the numeric variables in both datasets. Compare
# them: which variables appear to be different and which variables appear to be similar, if you compare
# 'study.one' and 'psyc122'?



############################################################################################################
## Part 3: Use histograms to examine the distributions of variables ########################################


# -- revision: practice to strengthen skills --


# -- Task 5 -- Draw histograms to examine the distributions of variables


# -- Here, focus on one variable, mean accuracy of understanding ('mean.acc')
# -- But -- this is new -- we look at the distribution of the same variable in data from
# two different but similar studies: 'study.one' and 'psyc122'

# -- write your code here and run it --


# -- encounter: make some new moves --


# -- Task 6 -- Write code to first create plots and second show the plots side-by-side for comparison
# -- Task 6 -- Produce plots to examine the distribution of 'mean.acc' in both the 'study.one' and 'psyc122'
# datasets
# -- hint: Task 6 -- We want comparison plots, we proceed in two steps


# -- First, write code to create -- but not show -- two plots
# -- hint: Task 6 -- you need to write ggplot() code to create a plot and assign <- the plot to a name,
# you will use the name next

# -- write your code here and run it --

# -- Second, write the code to show the plots side-by-side, referencing each plot by name
# -- hint: Task 6 -- you will use the plot names to show plot one + plot two in the Plot window

# -- write your code here and run it --


# -- Now you can answer questions like the following

# -- Q.4. -- What differences do you see when you compare the distributions?

# -- Q.5. -- What similarities do you see when you compare the distributions?

# -- Q.6. -- I invite you to speculate: what are the reasons for the differences or similarities?



############################################################################################################
## Part 4: Now draw scatterplots to examine associations between variables #################################


# -- consolidate: practice to strengthen skills --


# -- Task 7 -- Create a scatterplot to examine the association between some variables
# -- Task 7 -- Here, we focus on the potential association between 'mean.self' and 'mean.acc'
# -- Task 7 -- We want to draw a scatterplot, to examine this association, for both the
# 'study.one' and the 'psyc122' datasets

# -- Consolidate on creating two plots that you show side-by-side for comparison

# -- First, as before, begin by creating two plot objects, with distinct names, and titles
# -- These should be:
# -- 1 -- scatterplots
# -- 2 -- showing the potential association between 'mean.acc' and 'mean.self'
# -- 3 -- for each of the 'study.one' and 'psyc122' datasets
# -- hint: Task 7 -- don't forget each code chunk must produce a plot object and you must assign
# the plot a name

# -- write your code here and run it --


# -- Remember, you can run the code chunk successfully -- and will see the code in blue
# in the console window in blue -- but will not see the plots in the Plot window
# -- That happens next

# -- Second, write code to show both plots in the Plot window

# -- write your code here and run it --


# -- Now you can answer these questions


# -- Q.7. -- What is the nature of the relationship between 'mean.self' and 'mean.acc'?

# -- Q.8. -- What does these plots suggest could be the answer to the research question:
# # 2. Can people accurately evaluate whether they correctly understand written health information?

# -- Q.9. -- Do we see the same relationship between 'mean.self' and 'mean.acc' in the 'study.one' and 'psyc122'
# data?
# -- Can you explain any differences or similarities that you see?



############################################################################################################


# -- Notice that drawing grids of plots to allow comparisons of trends or patterns between datasets
# is a technique -- using 'small multiples' -- in advanced professional data visualization
# -- I discuss this in the week 17 lecture on data visualization



############################################################################################################
## Part 5: Now draw boxplots to examine associations between variables #####################################


# -- consolidate: practice to strengthen skills --


# -- Task 8.1. -- Create boxplots to examine the association between a continuous numeric outcome variable
# like 'mean.acc' and a categorical variable like 'gender'
# -- Task 8.1. -- Do this for the 'psyc122' dataset

# -- Notice:
# -- the 'psyc122' dataset has two variables, 'gender' and 'GENDER'
# -- if you look at summary(psyc122) you can see that R is treating 'GENDER' like a numeric variable

# -- So, if you want to plot 'mean.acc' for different 'GENDER' groups
# first, you need to make R treat GENDER like a categorical variable or factor
# -- You did this before, in week 16, using as.factor()
# -- Revise what code you need to use and edit and run it here

# -- write your code here and run it --


# -- Alternatively, I pre-coded 'gender' as a factor to represent gender groups in the sample 
# so you can just use the pre-coded 'gender' variable

# -- write your code here and run it --


# -- Task 8.2. -- Can you make an edit of the plot to make it a bit more effective?
# -- hint: Task 8.2. -- It would be helpful to see both the raw data -- the scores per person --
# as well as the summary information provided by the boxplots
# -- Check out the how-to guide for how to do this

# -- write your code here and run it --


# -- The plot should show:
# -- boxplots to indicate the average (median) and spread (percentiles) in 'mean.acc' scores for each group;
# -- plus, with points, individual 'mean.acc' scores for the people in each group


# -- Now you can use the plots to answer questions like the following


# -- Q.10. -- Does anything in the plots give you reason to question the nature of the participant sample?



############################################################################################################


# -- Notice that drawing plots which show *both* summaries (like boxplots) and raw data (scores as points)
# -- Is another common professional visualization technique
# -- It is effective because these kinds of plots help you to see the pattern or trend *and* 
# the nature of the underlying sample  



############################################################################################################
## Part 6: Use a linear model to to answer the research questions ##########################################


# -- revision: make sure you are confident about doing these things --


# -- One of our research questions is:
# 2. Can people accurately evaluate whether they correctly understand written health information?

# -- We can answer this question by examining whether mean self-rated accuracy of understanding predicts, 
# in a linear model, mean accuracy of understanding


# -- Task 9 -- Examine the relation between outcome mean accuracy ('mean.acc') and 
# the predictor mean self-rated accuracy ('mean.self')
# -- Do this for both 'psyc122' and 'study.one' datasets
# -- hint: Task 9 -- We use lm()

# -- write your code here and run it --


# -- If you look at the model summaries you can answer the following questions  

# -- Q.11. -- What is the estimate for the coefficient of the effect of the predictor, mean.self, in 'study.one'?

# -- Q.12. -- What is the estimate for the coefficient of the effect of the predictor, mean.self, in 'psyc122'?

# -- Q.13. -- Are these effects significant?

# -- Q.14. -- What is the adjusted R-squared for the 'study.one' model?
# -- A.14. -- For study.one data, for the model, adjusted R-squared = .232 -- the model explains about 23% of 
# outcome 'mean.acc' variance

# -- Q.15. -- What is the adjusted R-squared for the 'psyc122' model?

# -- Q.16. -- Do you think that in both studies we see similar or different relationships between self-rated
# evaluations of understanding and performance on tests of that understanding?


# -- encounter: make some new moves --


# -- Task 10 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# multiple different predictors
# -- Do this for both datasets
# -- hint: Task 10 -- We use lm()


# -- The first of our research questions is:
# 1. What person attributes predict success in understanding?


# -- Given our theoretical understanding of how reading comprehension works, we can expect that variation
# in a number of different measures of skill or knowledge should predict variation in accuracy of
# understanding
# -- We can fit a linear model including multiple predictors to estimate the "effects" of all these
# variables together

# -- Fit a model using lm(), with 'mean.acc' as the outcome and 'AGE, SHIPLEY, HLVA, FACTOR3' as predictors
model.one.acc <- lm(mean.acc ~ AGE + SHIPLEY + HLVA + FACTOR3,
                    data = study.one)
summary(model.one.acc)

# -- Notice:
# -- This model is different compared to the model.one.acc you see in the how-to guide
# -- because we do not have 'QRITOTAL' data in the 'psyc122' sample so cannot compare analyses
# of the 'study.one' and 'psyc122' data without excluding the 'QRITOTAL' variable


# -- This is a good place to test the impact of making different choices when we specify model predictors
# -- In the lecture, I talk about the impact of different decisions on the analysis different people decide to do


# -- Q.17. -- What are the results if we fit a linear model of outcome 'mean.acc' including as predictors
# 'AGE, SHIPLEY, HLVA, FACTOR3, QRITOTAL' for the 'study.one' dataset?

# -- Q.18. -- What are the results if we fit a linear model of outcome 'mean.acc' including as predictors
# 'AGE, SHIPLEY, HLVA, FACTOR3' but not 'QRITOTAL' for the 'study.one' dataset?

# -- Q.19. -- Besides the difference in the inclusion of 'QRITOTAL' are the results of these analyses
# of the same 'study.one' dataset similar or different?


# -- Now we want to compare the results of the same analysis -- a model with the same predictor --
# but in each of the two datasets 'psyc122' and 'study.one'


# -- Q.20. -- Can you now fit the same model -- same predictors -- for the 'study.one' and 'psyc122' datasets?
# -- hint: Q.20. -- In both models, the formula should be the same: 
# -- outcome should be 'mean.acc'
# -- predictors should be 'AGE, SHIPLEY, HLVA, FACTOR3'
# -- hint: Q.20. -- You just need to change the dataset name:

# -- write your code here and run it --


# -- Now let's focus on extracting and reporting the results of an analysis like this


# -- Q.21. -- Look at the results summary for the model of 'study.one' data, can you identify:

# -- Q.21.1. -- Adjusted R-squared?

# -- Q.21.2. -- F-test results?  

# -- Q.21.3. -- The significant coefficients

# -- Q.21.4. -- The nature of the relationships between outcome and predictor, for each
# predictor, suggested by the significant coefficients?


# -- Q.22. -- Can you identify the same information for the model of 'psyc122' data?

# -- Q.22.1. -- Adjusted R-squared?

# -- Q.22.2. -- F-test results?  

# -- Q.22.3. -- The significant coefficients

# -- Q.22.4. -- The nature of the relationships suggested by the significant coefficients?


# -- Q.23. -- Can you compare the results from the analyses of the data from the two studies?
# -- hint: Q.23. -- Does the comparison indicate similarities or differences between results?

# -- Q.24. -- Can you think of reasons to explain the similarities or differences between the analyses
# of the influences on accuracy of understanding in the two studies?



############################################################################################################


# -- Notice that in these kinds of comparisons -- of the results of analyses -- we are examining:

# -- first, the stability of results -- and how results may vary given different analysis choices
# -- this connects to ideas about (methods) reproducibility or replication discussed in the lecture and 
# in other modules

# -- second, the stability or reproducibility of results
# -- we can compare the results from different studies -- and often do, in psychology -- in an effort
# to identify if critical effects are reproducible across different studies, different samples,
# different kinds of participants
# -- these questions connect to discussions of replication in the lecture and in other modules

# -- We do this to establish or critically evaluate our evidence



############################################################################################################
## Part 7: Use a linear model to generate predictions ######################################################


# -- encounter: make some new moves --


# -- Task 11 -- We can use the model we have just fitted to plot the model predictions
# -- Task 11 -- Do this for the model of the 'psyc122' data, for the significant effect or effects you see
# in your analysis
# -- hint: Task 11 -- Use the ggpredict() function


# -- We create the plot in three steps:
# -- check out the code in the how-to guide if you are unsure on what you need to do

# -- First: fit a model -- and give the model object a name:

# -- write your code here and run it --

# -- Second, generate the predictions, specifying the variable or effect you want predictions for
# by specifying the name of the variable in ggpredict(... terms = ...)

# -- write your code here and run it --


# -- Q.25. -- Can you interpret the model summary results coefficient for the significant effect,
# given what you see in the plot?



############################################################################################################
## Optional: Export a plot so you can use it in a report ###################################################


# -- encounter: make some new moves --


# -- Task 12 -- Can you export a plot so that you can use it in a report?
# -- hint: Task 12 -- There are different ways to do this, we shall look at two


# -- 1 -- Click on the Export button at the top of the Plots window and save the image


# -- 2 -- We can use ggsave() -- this works in two steps:

# -- First, draw the plot:

# -- write your code here and run it --

# -- Second, use ggsave() to save it:

# -- write your code here and run it --


# -- Notice:
# -- Just as we did earlier, we can generate multiple plots and use patchwork to produce
# a grid of prediction plots
# -- This is what I did to create images in the week 19 lecture slides 
# -- Can you work out how to do this?  



############################################################################################################